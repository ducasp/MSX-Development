#include <iostream>
#include <fstream>
#include <algorithm>

/*
  sample JIC structure

  00 �` 05    'JIC' 00 00 00  ; JIC identifier

  ...

  82 �` 83    1c 00           ; data type (data?)
  84 �` 87    0c 00 08 00     ; following data length (little-endian)
  88 �` 80093                 ; data (12B + 8192kB)

  ...

*/

typedef short DataType;
static const char JIC_HEADER[] = { 'J', 'I', 'C', 0x00, 0x00, 0x00 };
static const int CONTENT_HEADER_SIZE = 12;

template <typename T> static T get(std::istream& is)
{
    char buffer[sizeof(T)];
    is.read(buffer, sizeof buffer);
    int result = 0;
    for (int i = 0; i < sizeof buffer; i++) {
        result |= buffer[i] << (i * 8);
    }
    return result;
}

int main(int argc, char** argv)
{
    if (argc < 3) {
        std::cout << std::endl
            << "jic2pld for EPCS16+ v1.2 by KdL (2023.11.24)" << std::endl
            << std::endl
            << "syntax:" << std::endl
            << "\tjic2pld <input-file-name> <output-file-name>" << std::endl;
        return -1;
    }

    std::ifstream ifs(argv[1], std::ios::in | std::ios::binary);
    if (!ifs.is_open()) {
        std::cout << "file cannot open : " << argv[1] << std::endl;
        return -2;
    }

    //  check JIC header
    char buffer[32 * 1024];
    ifs.read(buffer, sizeof JIC_HEADER);
    if (memcmp(buffer, JIC_HEADER, sizeof JIC_HEADER) != 0) {
        std::cout << "bad input file : " << argv[1] << std::endl;
        return -3;
    }

    get<DataType>(ifs);	// dummy read

    // read chunks
    int chunks = get<int>(ifs);
    //  std::cout << "chunks = " << chunks << std::endl;
    int fileSize = 0;
    //  output file size
    int remain = 2097152;
    for (int i = 0; i < chunks; i++) {
        int type = get<DataType>(ifs);  // dummy read
        int dataSize = get<int>(ifs);
        if (type == 0x1c) {
            ifs.seekg(CONTENT_HEADER_SIZE, std::ios::cur);
            fileSize = abs(dataSize - CONTENT_HEADER_SIZE);
            std::cout << "input data size = " << fileSize << " bytes" << std::endl
                    << "output file size = " << remain << " bytes" << std::endl;
            break;
        }
        else {
            ifs.seekg(dataSize, std::ios::cur);
        }
    }

    std::ofstream ofs(argv[2], std::ios::out | std::ios::trunc | std::ios::binary);
    if (!ofs.is_open()) {
        std::cout << "file cannot create : " << argv[2] << std::endl;
        return -4;
    }

    while (remain > 0) {
        int ofp = ifs.tellg();
        ifs.read(buffer, remain > sizeof buffer ? sizeof buffer : remain);
        int cfp = ifs.tellg();
        int read = cfp - ofp;
        remain -= read;
        ofs.write(buffer, read);
    }

    return 0;
}
