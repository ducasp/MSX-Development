#include <iostream>
#include <fstream>
#include <algorithm>

/*
  sample POF structure

  00 �` 05    'POF' 00 00 00  ; POF identifier
  06 �` 07    01 00           ; data type?
  08 �` 0B    05 00 00 00     ; number of chunks (little-endian)

  0C �` 0D    01 00           ; data type (Product Name?)
  0E �` 11    55 00 00 00     ; following data length (little-endian)
  12 �` 66    "Quartus �c "   ; data

  67 �` 68    02 00           ; data type (Device Type?)
  69 �` 6a    06 00 00 00     ; following data length (little-endian)
  6b �` 72    "EPCS4"         ; data

  73 �` 74    03 00           ; data type (Title?)
  75 �` 78    09 00 00 00     ; following data length (little-endian)
  79 �` 81    "Untitle"       ; data

  82 �` 83    11 00           ; data type (data?)
  84 �` 87    0c 00 08 00     ; following data length (little-endian)
  88 �` 80093                 ; data (12B + 512KB)

  80094 �` 80095 08 00        ; data type (Check Sum?)
  80096 �` 80099 02 00 00 00  ; following data length
  8009a �` 8009b 76 2d        ; data
*/

typedef short DataType;
static const char POF_HEADER[] = {'P', 'O', 'F', 0x00, 0x00, 0x00};
static const int CONTENT_HEADER_SIZE = 12;

template <typename T> static T get(std::istream& is)
{
    char buffer[sizeof(T)];
    is.read(buffer, sizeof buffer);
    int result = 0;
    for (int i = 0; i < sizeof buffer; i++) {
	result |= buffer[i] << (i * 8);
    }
    return result;
}

int main(int argc, char** argv)
{
    if (argc < 3) {
	std::cout << "pof2pld" << std::endl
	    << "usage:" << std::endl
	    << "\tpof2pld <input-file-name> <output-file-name>" << std::endl;
	return -1;
    }

    std::ifstream ifs(argv[1], std::ios::in | std::ios::binary);
    if (!ifs.is_open()) {
	std::cout << "file cannot open " << argv[1] << std::endl;
	return -2;
    }

    //  check POF header
    char buffer[32 * 1024];
    ifs.read(buffer, sizeof POF_HEADER);
    if (memcmp(buffer, POF_HEADER, sizeof POF_HEADER) != 0) {
	std::cout << "bad input file of " << argv[1] << std::endl;
	return -3;
    }

    get<DataType>(ifs);	// dummy read

    // read chunks
    int chunks = get<int>(ifs);
    std::cout << "chunks=" << chunks << std::endl;
    int fileSize = 0;
    for (int i = 0; i < chunks; i++) {
	int type = get<DataType>(ifs);	// dummy read
	int dataSize = get<int>(ifs);
	if (type == 0x11) {
	    std::cout << "data size=" << dataSize << " bytes" << std::endl;
	    ifs.seekg(CONTENT_HEADER_SIZE, std::ios::cur);
	    fileSize = dataSize - CONTENT_HEADER_SIZE;
	    break;
	} else {
	    ifs.seekg(dataSize, std::ios::cur);
	}
    }

    std::ofstream ofs(argv[2], std::ios::out | std::ios::trunc | std::ios::binary);
    if (!ofs.is_open()) {
	std::cout << "file cannot create " << argv[2] << std::endl;
	return -4;
    }

    int remain = fileSize;
    while (remain > 0) {
	int ofp = ifs.tellg();
	ifs.read(buffer, remain > sizeof buffer ? sizeof buffer : remain);
	int cfp = ifs.tellg();
	int read = cfp - ofp;
	remain -= read;
	ofs.write(buffer, read);
    }

    return 0;
}

